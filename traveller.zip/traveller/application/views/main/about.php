
			<li class="active">About</li>
		</ol>
	</div>
	<!-- //breadcrumb -->
	<!--  about-page -->
	<div class="about">
		<div class="container"> 
			<h3 class="w3ls-title w3ls-title1">Tentang Kami</h3>
			<div class="about-text">	
				<p>Pemadam Kelaparan adalah makanan dengan empat macam menu yang siap saji. Dengan gabungan bumbu asli Indonesia dan dikemas dengan tampilan modern. Kini kami hadir melalui website dengan pemesanan minimal 10 box dan dapat dikirim kapan saja ke seluruh wilayah Surabaya.</p> 
				<div class="ftr-toprow">
					<div class="col-md-4 ftr-top-grids">
						<div class="ftr-top-left">
							<i class="fa fa-truck" aria-hidden="true"></i>
						</div> 
						<div class="ftr-top-right">
							<h4>Free Delivery</h4>
							<p>Anda dapat mendapatkan layanan antar gratis dengan minimal pembelian 10 porsi</p>
						</div> 
						<div class="clearfix"> </div>
					</div> 
					<div class="col-md-4 ftr-top-grids">
						<div class="ftr-top-left">
							<i class="fa fa-user" aria-hidden="true"></i>
						</div> 
						<div class="ftr-top-right">
							<h4>Fast Response</h4>
							<p>Customer service yang ramah dan fast response pada jam kerja</p>
						</div> 
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 ftr-top-grids">
						<div class="ftr-top-left">
							<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
						</div> 
						<div class="ftr-top-right">
							<h4>Delicious</h4>
							<p>Kami dapat menjamin rasa makanan tetap lezat selama pengiriman hingga waktu makan. </p>
						</div>
						<div class="clearfix"> </div>
					</div> 
					<div class="clearfix"> </div>
				</div> 
				<div class="clearfix"> </div>
			</div>
			<div class="history">
				<h3 class="w3ls-title">Bagaimana cara memesan?</h3>
				<p>Cukup masuk menggunakan akun anda, pilih menu makanan yang anda inginkan, isi formulir pembelian tempat tujuan. Pemesanan dapat dilakukan maksimal H-1 dan dibayar saat pengantaran makanan.</p> 
			</div>
		</div>
	</div>