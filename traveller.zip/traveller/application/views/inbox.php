<div class="inner-block">
    <!--market updates updates-->

    <a href="<?php echo base_url().'MyController/readData'?>">
        <span>
            <div class="col-md-6 market-update-gd" >
                <div class="market-update-block clr-block-3">
                    <div class="col-md-5 market-update-left">
                        <h4>Pesan Baru</h4>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </span></a>

    <a href="<?php echo base_url().'MyController/readData'?>">
        <span>
            <div class="col-md-6 market-update-gd" >
                <div class="market-update-block clr-block-2">
                    <div class="col-md-5 market-update-left">
                        <h4>Pesan Lama</h4>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </span></a>

    <div class="clearfix"> </div>
<br> <br>
    <div class="col-md-5 market-update-gd">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Nomor Pesanan</th>
                    <th>Pemesan</th>
                    <th>Pesanan</th>                                   
                    <th>Alamat Kirim</th>
                    <th>Edit Status</th>
                </tr>
            </thead>

            
        </table>

    </div>
</div>
