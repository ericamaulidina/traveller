<?php  

class My_Model extends CI_Model {

   /* function getData() {
        $this->db->select('*');
        $this->db->join('pesanan', 'orderdetail.orderid = pesanan.id')->join('datauser', 'pesanan.emailuser = datauser.email')->join('base_menu','orderdetail.id_pw = base_menu.id_pw');
        $query = $this->db->get_where('orderdetail',array('status_order'=>'proses'));
        return $query->result_array();
    }
        

    function addData($data) {
        $this->db->insert('user', $data);
    }


    function menunya() {
        $query = $this->db->get('base_menu');
        return $query->result_array();
    }*/


    
   /* function ordering() {
        $query = $this->db->get('order_pw');
        return $query->result_array();
    }*/
    
   

    public function Updating($tableName,$where)
    {
        $data = $this->db->get_where($tableName,$where);
        return $data->result_array();
    }
    

   /* public function getUser() {
        $query = $this->db->get('datauser');
        return $query->result_array();
    }*/
    public function addOrder($ord) {
        $this->db->insert('order_pw', $ord);
    }

    public function getTotalDataOrder($username, $id_pw, $jumlah_orang, $addition)
    {
        $this->db->where('username', $username);
        $this->db->where('id_pw', $id_pw);
        $this->db->where('jumlah_orang', $jumlah_orang);
        $this->db->where('addition', $addition);
        $query = $this->db->get('order_pw');
        return $query->num_rows();
    }
    
    public function deleteOrder($username, $id_pw, $jumlah_orang, $addition)
    {
        $this->db->where('username', $username);
        $this->db->where('id_pw', $id_pw);
        $this->db->where('jumlah_orang', $jumlah_orang);
        $this->db->where('addition', $addition);
        $this->db->delete('order_pw');
    }

    public function addUser($user)
    {
        $this->db->insert('datauser', $user);
    }

    public function getTotalRowUser($username, $full_name, $address, $email, $password)
    {
        $this->db->where('username', $username);
        $this->db->where('full_name', $full_name);
        $this->db->where('address', $address);
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get('datauser');
        return $query->num_rows();   
    }
    
    public function deleteRowUser($username, $full_name, $address, $email, $password)
    {
        $this->db->where('username', $username);
        $this->db->where('full_name', $full_name);
        $this->db->where('address', $address);
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $this->db->delete('datauser'); 
    }

    
    public function cek_login($email, $password){     
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        return $this->db->get("datauser");
    }
    public function getMenu(){
        $query = $this->db->get('base_menu');
        return $query->result_array();
    }
    
}

?>