<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if ($this->session->userdata('username') != null || $this->session->userdata('username') != ""){

        } else {
            redirect('Welcome');
        }
        $this->load->library('form_validation');
        $this->load->library('cart');
        $this->load->model('My_Model');
        $this->load->helper('url');
        $this->load->helper('form');
    }

   public function index(){
        $this->load->view('on/headerberanda');
        $this->load->view('main/home');
        $this->load->view('main/footer');
    }
    
    public function about(){
        $this->load->view('on/header');
        $this->load->view('main/about');
        $this->load->view('main/footer');
    }

    public function menu(){
        $this->load->view('on/header');
        $nasi = $this->My_Model->getMenu();
        $this->load->view('on/menu', array('nasi' => $nasi));

        $this->load->view('main/footer');
    }
   

    public function success(){
        $this->load->view('on/header');
        $this->load->view('on/success');
        $this->load->view('main/footer');
    }

    public function logout(){
        $data = array('email','username','password');
        $this->session->unset_userdata($data);
        redirect('Welcome');}

    
    function checkout($id_pw){
        $where = array ('id_pw'=>$id_pw);
        $b = $this->My_Model->updating('base_menu',$where);
        $data = array(
            'id_pw'=> $b[0]['id_pw'],
            'nama_paket'=> $b[0]['nama_paket'],
            'kuota'=> $b[0]['kuota'],
            'deskripsi'=> $b[0]['deskripsi'],
            'harga'=> $b[0]['harga'],
            'date'=> $b[0]['tanggal_berangkat'],
            'image'=> $b[0]['image']
        );
        $this->load->view('on/header');
        $this->load->view('on/checkout',$data);
        $this->load->view('main/footer');
    }

    function editProduk($id_pw){
        $where = array ('id_pw'=>$id_pw);
        $b = $this->My_Model->updating('base_menu',$where);
        $data = array(
            'id_pw'=> $b[0]['id_pw'],
            'nama_paket'=> $b[0]['nama_paket'],
            'kuota'=> $b[0]['kuota'],
            'deskripsi'=> $b[0]['deskripsi'],
            'harga'=> $b[0]['harga'],
            'date'=> $b[0]['tanggal_berangkat'],
            'image'=> $b[0]['image']
        );
        $this->load->view('on/header');
        $this->load->view('on/detail',$data);
        $this->load->view('main/footer');
    }


    /*public function detail($id_pw){
        $where = array ('id_pw'=>$id_pw);
        $product = $this->My_Model->find($id_pw);
        $data = array(
            'nama'     => $product->nama_paket,
            'deskripsi'     => $product->deskripsi,
            'kuota'     => $product->kuota,
            'price'   => $product->harga,
            'date'    => $product->tanggal_berangkat
        );
        $this->load->view('on/header');
        $this->load->view('on/detail',$data);
        $this->load->view('main/footer');
    }*/


    public function order(){
        $this->load->helper("security");
        $ord = array(
            'username' => $this->input->post('username', TRUE),
            'id_pw' => $this->input->post('id_pw', TRUE),
            'jumlah_orang' => $this->input->post('jumlah_orang', TRUE),
            'addition' => $this->input->post('request', TRUE));

        $this->My_Model->addOrder($ord);
        $this->load->view('on/header');
        $this->load->view('on/success');
        $this->load->view('main/footer');
    }

}
?>