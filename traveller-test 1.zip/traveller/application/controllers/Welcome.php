+<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
		public function __construct() {
			parent::__construct();
			if ($this->session->userdata('username') != null || $this->session->userdata('username') != ""){
				redirect('Member');
			} else {
				
			}
			$this->load->library('form_validation');
			$this->load->model('My_Model');
			$this->load->helper('url');
		}
	
		public function index(){
			$this->load->view('main/headerberanda');
			$this->load->view('main/home');
			$this->load->view('main/footer');
		}
		public function signup(){
			$this->load->view('main/header');
			$this->load->view('main/signup');
			$this->load->view('main/footer');
		}
		public function login(){
			$this->load->view('main/header');
			$this->load->view('main/login');
			$this->load->view('main/footer');
		}
		
		public function about(){
			$this->load->view('main/header');
			$this->load->view('main/about');
			$this->load->view('main/footer');
		}
		public function menu(){
			$this->load->view('main/header');
			$nasi = $this->My_Model->getMenu();
			$this->load->view('main/menu', array('nasi' => $nasi));
			
			$this->load->view('main/footer');
		}
		public function careers(){
			$this->load->view('main/header');
			$this->load->view('main/careers');
			$this->load->view('main/footer');
		}
		public function offers(){
			$this->load->view('main/header');
			$this->load->view('main/offers');
			$this->load->view('main/footer');
		}
		public function privacy(){
			$this->load->view('main/header');
			$this->load->view('main/privacy');
			$this->load->view('main/footer');
		}
		public function products(){
			$this->load->view('main/header');
			$this->load->view('main/privacy');
			$this->load->view('main/footer');
		}
		public function terms(){
			$this->load->view('main/header');
			$this->load->view('main/privacy');
			$this->load->view('main/footer');
		}
    
        public function gagalsignup(){
		
			$this->load->view('main/gagalsignup');
			$this->load->view('main/footer');
		}
    
		public function validation(){
			$this->form_validation->set_rules('username','username', 'trim|required');
			$this->form_validation->set_rules('full_name','full_name', 'trim|required');
			$this->form_validation->set_rules('address','address', 'trim|required');
			$this->form_validation->set_rules('email','email', 'trim|required');
			$this->form_validation->set_rules('password','password', 'trim|required|min_length[8]');
			$this->form_validation->set_rules('konfirmasi_password','konfirmasi password', 'trim|required|matches[password]');

			if($this->form_validation->run() != false){
				$this->load->helper("security");
				$user = array(
				'username' => $this->input->post('username' , TRUE),
				'full_name' => $this->input->post('full_name', TRUE),
				'address' => $this->input->post('address', TRUE),
				'email' => $this->input->post('email', TRUE),
				'password' => md5($this->input->post('password', TRUE))
				);

				$this->My_Model->addUser($user);
				$this->index();
			}else{
				redirect ('Welcome/gagalsignup');
			}
		}
		/*public function daftar(){
			$user = array(
				'username' => $this->input->post('username'),
				'full_name' => $this->input->post('full_name'),
				'address' => $this->input->post('address'),
				'email' => $this->input->post('email'),
				'password' => md5($this->input->post('password'))
			);

			$this->My_Model->addUser($user);
			$this->index();
		}*/
		public function masuk(){
			$email = $this->input->post('email');
			$password = md5($this->input->post('password'));
			$cek = $this->My_Model->cek_login($email, $password);
			if($cek->num_rows() == 1){
	 			foreach ($cek->result() as $user) {
	 				$sess_user['username'] = $user->username;
	 				$sess_user['email'] = $user->email;
	 				$this->session->set_userdata($sess_user);
	 			}
	 			redirect('Member');
			}else{
				redirect ('Welcome/login');
			}
		}
    public function viewProduk($id_pw){
        $where = array ('id_pw'=>$id_pw);
        $b = $this->My_Model->updating('base_menu',$where);
        $data = array(
            'id_pw'=> $b[0]['id_pw'],
            'nama_paket'=> $b[0]['nama_paket'],
            'kuota'=> $b[0]['kuota'],
            'deskripsi'=> $b[0]['deskripsi'],
            'harga'=> $b[0]['harga'],
            'date'=> $b[0]['tanggal_berangkat'],
            'image'=> $b[0]['image']
        );
        $this->load->view('main/header');
        $this->load->view('main/detail',$data);
        $this->load->view('main/footer');
    }
    
}
?>